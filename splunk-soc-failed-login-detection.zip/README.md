# Failed Login & Brute Force Detection – Splunk SOC Project

## Objective
To detect and investigate brute force and password spray attacks using Windows Security authentication logs in Splunk SIEM.

## Log Source
- Windows Security Logs
- Event ID: 4625 (Failed Login)
- Index: wineventlog
- Source: WinEventLog:Security

## Detection Use Cases
- Multiple failed login attempts on a single user account
- Password spray attacks from a single source IP
- Correlation of failed and successful login attempts

## Tools Used
- Splunk SIEM
- Windows Event Logs

## MITRE ATT&CK Mapping
- Tactic: Credential Access (TA0006)
- Technique: Brute Force (T1110)
