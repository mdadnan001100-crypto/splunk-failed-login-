# Investigation Steps – Failed Login Alert

1. Review alert details (username, source IP, timestamp)
2. Check whether the source IP is internal or external
3. Verify if the user is a normal user or service account
4. Look for successful login attempts after failures (Event ID 4624)
5. Identify attack type:
   - Brute Force: many attempts on one user
   - Password Spray: one IP targeting many users
6. Classify alert as false positive or true positive
7. Recommend response actions (account lock, IP block, escalation)
