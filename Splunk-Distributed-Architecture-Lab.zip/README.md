# 🔥 Distributed Splunk 3-Tier Architecture Lab

## 📌 Project Objective
This project demonstrates the deployment of a distributed Splunk Enterprise environment consisting of:
- Search Head
- Indexer
- Universal Forwarder (Target Machine)

The lab simulates a real-world enterprise SOC logging architecture.

## 🏗 Architecture Overview

Universal Forwarder (Target Machine)
        |
        | TCP 9997
        v
Indexer (Data Parsing & Storage)
        |
        | TCP 8089
        v
Search Head (Search & Dashboards)

## 🔌 Ports Used
- 8000 → Web Interface
- 8089 → Management Port
- 9997 → Receiving Port

## ⚙️ Skills Demonstrated
- Splunk Enterprise Installation
- Universal Forwarder Configuration
- Distributed Search Setup
- TCP Port Management
- Firewall Configuration
- Log Monitoring & Troubleshooting

## 👨‍💻 Author
Mohammed – SOC Analyst Aspirant
