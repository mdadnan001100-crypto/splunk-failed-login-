# 🔐 Firewall Configuration

## On Indexer
sudo ufw allow 9997
sudo ufw allow 8089

## On Search Head
sudo ufw allow 8000

Verify:
sudo ufw status
