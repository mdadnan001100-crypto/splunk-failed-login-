# 🛠 Installation Guide

## 1️⃣ Install Splunk Enterprise (Indexer)

wget -O splunk.tgz 'https://download.splunk.com/products/splunk/releases/9.x.x/linux/splunk-9.x.x.tgz'
tar -xvzf splunk.tgz
sudo mv splunk /opt/
cd /opt/splunk/bin
sudo ./splunk start --accept-license

Enable receiving port:
sudo ./splunk enable listen 9997

## 2️⃣ Install Splunk Enterprise (Search Head)
Repeat installation steps.
Access Web UI:
http://<SearchHead-IP>:8000

## 3️⃣ Install Universal Forwarder
wget -O splunkforwarder.tgz 'https://download.splunk.com/products/universalforwarder/releases/9.x.x/linux/splunkforwarder-9.x.x.tgz'
tar -xvzf splunkforwarder.tgz
sudo mv splunkforwarder /opt/
cd /opt/splunkforwarder/bin
sudo ./splunk start --accept-license

## 4️⃣ Connect Forwarder to Indexer
sudo ./splunk add forward-server <Indexer-IP>:9997

## 5️⃣ Monitor Logs
sudo ./splunk add monitor /var/log/auth.log
