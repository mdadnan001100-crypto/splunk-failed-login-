# 🛠 Troubleshooting Guide

Check Splunk status:
sudo ./splunk status

Verify Forwarder connection:
sudo ./splunk list forward-server

Check Indexer listening port:
netstat -an | grep 9997

Common Issues:
- Port 9997 not enabled
- Firewall blocking traffic
- Incorrect Indexer IP
- Splunk service stopped
